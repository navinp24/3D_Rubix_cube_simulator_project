from kociemba import solve
from cube_by_keys import *
from cube_by_not import *
from cube_by_color import *
from change_for_kociemba import *
from cube_scan import *
from solution import *
from pros import *
from tkinter import *

rubiks_cube_simulator()
root = Tk()
root.title("Rubik's Cube Solver")
root.geometry("400x400")
root.mainloop()