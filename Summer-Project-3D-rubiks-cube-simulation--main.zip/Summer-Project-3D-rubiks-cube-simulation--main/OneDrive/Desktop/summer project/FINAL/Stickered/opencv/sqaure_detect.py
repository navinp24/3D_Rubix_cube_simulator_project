from cv2 import VideoCapture, imshow, waitKey, destroyAllWindows, GaussianBlur, cvtColor, COLOR_BGR2GRAY, Canny, findContours, drawContours, RETR_LIST, CHAIN_APPROX_SIMPLE, arcLength, approxPolyDP, contourArea, isContourConvex, boundingRect
from numpy import * 

def is_square(cnt, epsilon_coef=0.02, min_area=1000):
    peri = arcLength(cnt, True)
    approx = approxPolyDP(cnt, epsilon_coef * peri, True)

    # 1c. We only care about 4-sided, convex shapes larger than min_area
    if len(approx) == 4 and isContourConvex(approx):
        area = contourArea(approx)
        if area > min_area:
            # 1d. Check aspect ratio: bounding rect width/height ≈ 1
            x, y, w, h = boundingRect(approx)
            ar = float(w) / h
            if 0.8 <= ar <= 1.2:
                return True, approx

    # If any of the checks fail, it’s not a square
    return False, None
    
def main():
    cap = VideoCapture(0)  # 0 = default webcam
    if not cap.isOpened():
        print("Cannot open camera")
        return

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        # Pre-processing
        gray = cvtColor(frame, COLOR_BGR2GRAY)
        blur = GaussianBlur(gray, (5, 5), 0)
        edges = Canny(blur, 50, 150)

        # Find and test contours
        contours, _ = findContours(edges, RETR_LIST,CHAIN_APPROX_SIMPLE)
        
        for cnt in contours:
            ok, square = is_square(cnt)
            if ok:
                # Draw the square in green
                drawContours(frame, [square], 0, (0, 255, 0), 2)

        # Show the result
        imshow('Square Detection', frame)

        # Exit on ESC
        if waitKey(1) & 0xFF == 27:
            break

    cap.release()
    destroyAllWindows()

if __name__ == "__main__": #is a Python idiom used  to ensure that certain parts of code are only executed when the script is run
     #directly, and not when it's imported as a module in another script.
    main()
