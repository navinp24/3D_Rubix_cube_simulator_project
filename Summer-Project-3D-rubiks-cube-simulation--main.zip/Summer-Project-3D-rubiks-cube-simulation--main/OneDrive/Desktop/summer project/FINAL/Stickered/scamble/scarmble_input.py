import kociemba

# placeholder: you'll fill this with your 6 faces × 3×3 stickers
color_state = [[['' for _ in range(3)] for _ in range(3)] for _ in range(6)]

s_in = input("Enter the scramble: ")
scramble = ''
i = 0
n = len(s_in)

while i < n:
    move = s_in[i]
    # only care about the six face moves
    if move in ('R','L','U','D','F','B'):
        # look ahead for a modifier
        if i+1 < n and s_in[i+1] == "'":
            # a counter-clockwise turn = three clockwise turns
            scramble += move
            scramble += move
            scramble += move

            i += 2
        elif i+1 < n and s_in[i+1] == '2':
            # a double turn = two cw turns
            scramble += move
            scramble += move

            i += 2
        else:
            # plain single turn
            scramble += move

            i += 1
    else:
        # anything else (spaces, invalid chars): skip
        i += 1

print("Parsed scramble sequence:", scramble)
solution = kociemba.solve(scramble)
