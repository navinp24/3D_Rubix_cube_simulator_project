# VPython (GlowScript) script
from re import I
from vpython import *
from allnot import rubiks_cube
from ipywidgets import FloatText, Button, VBox
from IPython.display import display

# Initial cube
cube = box(size=vector(5, 5, 5), color=color.cyan)

# Input field for cube size
input_box = FloatText(
    value=5.0,
    description='Side:',
    disabled=False
)

# Button to trigger update
button = Button(description='Update Cube')

# Function to change size dynamically
def on_click(b):
    side = input_box.value
    cube.size = vector(side, side, side)

# Set the event handler
button.on_click(on_click)

# Show input + button
display(VBox([input_box, button]))

while True:
    rate(100)

