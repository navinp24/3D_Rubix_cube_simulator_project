# function to find the solution of the scramble
import pycuber as pc 
import kociemba
def solve_with_kociemba(scramble: str) -> str:
        cube = pc.Cube()
        
        for mv in scramble.split():
            cube(mv)
        state = build_facelet_string(cube)
        return kociemba.solve(state)
    
def build_facelet_string(cube: pc.Cube) -> str:
    face_order = ["U", "R", "F", "D", "L", "B"]
    color_map = {
        'white': 'D',
        'red': 'L',
        'green': 'F',
        'yellow': 'U',
        'orange': 'R',
        'blue': 'B',
    }
    facelet = []
    for face in face_order:
        mat = cube.get_face(face)
        for row in mat:
            for square in row:
                clr = square.colour.lower()
                if clr not in color_map:
                    raise ValueError(f"Unknown colour '{clr}'")
                facelet.append(color_map[clr])
    return "".join(facelet)
    

def  solution_of_scramble(scramble):
    sol = solve_with_kociemba(scramble)
    return sol

# scamble = input("Scramble: ")
# sol = solution_of_scramble(scamble)
# print(sol)